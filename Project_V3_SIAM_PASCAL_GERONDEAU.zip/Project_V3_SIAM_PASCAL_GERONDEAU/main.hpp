#include <allegro.h>
#include <conio.h>
//#include <windows.h>
#include <winalleg.h>
#include <iostream>
#include "include\Player.hpp"
#include "include\Mountain.hpp"
#include "include\Game.hpp"
#include "include\Graphic.hpp"


